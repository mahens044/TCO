import { Component, OnInit, Input } from '@angular/core';
import {Router } from '@angular/router';

@Component({
  selector: 'app-client-modal',
  templateUrl: './client-modal.component.html',
  styleUrls: ['./client-modal.component.scss']
})
export class ClientModalComponent {
    @Input() modalCreated : string; 
    @Input() duration1 : string; 
    @Input() date1 : string; 
    @Input() cost1 : string; 

    // @Output() onModalCreated = new EventEmitter<void>();
    // onSelected(){
    //     console.log("test");
    //     this.recipeSelected.emit();
    
    //   }
}
