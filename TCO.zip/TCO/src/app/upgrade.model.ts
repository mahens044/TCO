export class Upgrade{
    public type: string;
    public duration: string;
    public date: string;
    public cost: number;
    
    constructor(type:string,duration:string,date:string,cost:number){
        this.type=type;
        this.duration=duration;
        this.date=date;
        this.cost=cost;
    }
}