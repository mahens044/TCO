import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-tco',
  templateUrl: './report-tco.component.html',
  styleUrls: ['./report-tco.component.scss']
})
export class ReportTCOComponent implements OnInit {

  constructor() { }
  val:boolean = false;
  ngOnInit(): void {
  }
  changepage(){
    this.val=true;
  }

}
